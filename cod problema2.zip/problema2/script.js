
let id = 0;
let questionsAnswered = 0;
let correctAnswers = 0;
let len = 50;
let cnt = new Array(50).fill(0);


function showQuestion() {
 
    document.getElementById("question-text").textContent = questions[id].question;
    document.querySelectorAll(".choice").forEach((choice, i) => { choice.textContent = questions[id].choices[i]; });
    document.getElementById("feedback").textContent = "";
}

function verifyAnswer(selected) {
    
    const feedback = document.getElementById("feedback");
    
    if (selected == questions[id].correct) {
        correctAnswers++;
        feedback.textContent = "Correct!";
     } else {
        feedback.textContent = "Incorrect!" + "The correct answer is " + questions[id].choices[questions[id].correct];
    }

    setTimeout(() => {

        questionsAnswered++;
        const progress = document.getElementById("progress");
        progress.value =  questionsAnswered;
      
        if (questionsAnswered < len) 
                  { generateRandomId(); showQuestion(); }
            else {document.querySelector(".quiz-container").innerHTML = `<p>Correct answers:  ${correctAnswers} out of ${len} questions.</p>`;}
    }, 2000);


}

function generateRandomId() {

    id = Math.floor(Math.random() * len);
    if (cnt[id] == 0) {
        cnt[id] = 1;
        console.log(id);
        console.log(cnt);
    }
    else { generateRandomId(); }
}


    generateRandomId();
    showQuestion();



