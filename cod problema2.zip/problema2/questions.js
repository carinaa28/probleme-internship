const questions = [
    {
        id:"0",
        question: "A green owl is the mascot for which app?",
        choices: ["Facebook", "Twitter", "Duolingo","Spotify"],
        correct: 2
    },
    {
      id:"1",
      question: "What is the capital of United Kingdom?",
      choices: ["London", "Paris", "Nairobi","San Francisco"],
      correct: 0
    },
    {
      id:"2",
      question: "How many days are there in a week?",
      choices: ["Five", "Three", "Eight","Seven"],
      correct: 3
    },
    {
        id:"3",
      question: "What is the closest planet to the sun?",
      choices: ["Earth", "Mercury", "Saturn","Jupiter"],
      correct: 1
    },
    {
        id:"4",
        question: "What is the most common surname in the United States?",
        choices: ["Smith", "Brown", "Jhonson","Rowland"],
        correct: 0
    },
    {  id:"5",
        question: "Which country drinks the most amount of coffee per person?",
        choices: ["Finland", "Italy", "France","Romania"],
        correct: 0
    },
    {   id:"6",
        question: "How many stars are on the United States flag?",
        choices: ["20", "30", "40","50"],
        correct: 3
    },
    {
        id:"7",
        question: "What year was the iPhone first released in?",
        choices: ["2005", "2007", "2009","2011"],
        correct: 1
    },
    {
        id:"8",
        question: "Who is considered the founder of modern computer science?",
        choices: ["Alan Turing", "Steve Jobs", "Bill Gates","Jeff Bezos"],
        correct: 0
    },
    {
        id:"9",
        question: "How many times has the Mona Lisa been stolen?",
        choices: ["Two", "Three", "One","Five"],
        correct: 2
    },
    {
        id:"10",
        question: "In what year did the Titanic sink?",
        choices: ["1812", "1816", "1912","1914"],
        correct: 2
    },
    {
        id:"11",
        question: "How many US presidents have been assassinated?",
        choices: ["1", "2", "3","4"],
        correct: 3
    },
    {
        id:"12",
        question: "Who painted The Last Supper?",
        choices: ["Vincent van Gogh", "Michelangelo", "Rembrandt","Leonardo Da Vinci"],
        correct: 3
    },
    {
        id:"13",
        question: "How many original James Bond novels were published?",
        choices: ["12", "13", "14","15"],
        correct: 0
    },
    {
        id:"14",
        question: "In what country was the Caesar salad invented?",
        choices: ["Italy", "Mexico", "Poland","The US"],
        correct: 1
    },
    {
        id:"15",
        question: "What is the primary ingredient in hummus?",
        choices: ["Black beans", "Edemame beans", "Chickpeas","Peas"],
        correct: 2
    },
    {
        id:"16",
        question: "In which Italian city was pizza first made?",
        choices: ["Naples", "Rome", "Palermo","Milano"],
        correct: 0
    },
    {
        id:"17",
        question: "Which country has the most Michelin starred restaurants?",
        choices: ["India", "France", "Japan","Italy"],
        correct: 1
    },
    {
        id:"18",
        question: "Where were French fries invented?",
        choices: ["Belgium", "France", "United Kingdom","Sweden"],
        correct: 0
    },
    {
        id:"19",
        question: "Which fast food restaurant has the most branches in the world?",
        choices: ["Subway", "McDonald's", "Kfc","Wendy's"],
        correct: 0
    },
    {
        id:"20",
        question: "Which musical genre originated in Jamaica in the 1960s?",
        choices: ["Salsa", "Flamenco", "Pop","Reggae"],
        correct: 3
    },
    {
        id:"21",
        question: "Which singer-songwriter released the album 21 in 2011",
        choices: ["Adele", "Taylor Swift", "Beyonce","Shakira"],
        correct: 0
    },
    {
        id:"22",
        question: "How many Spice Girls were there in the original lineup?",
        choices: ["3", "4", "5","6"],
        correct: 2
    },
    {
        id:"23",
        question: "Who composed the famous ballet, Swan Lake?",
        choices: ["Stravinsky", "Tchaikovsky", "Prokofiev","Dostoievski"],
        correct: 1
    },
    {
        id:"24",
        question: "Who was the best-selling musical artist in the US in 2022?",
        choices: ["Taylor Swift", "Justion Bieber", "Drake","Shakira"],
        correct: 2
    },
    {
        id:"25",
        question: "What is the primary gas that makes up the Earth's atmosphere?",
        choices: ["Nitrogen", "Oxygen", "Carbon dioxide","Helium"],
        correct: 0
    },
    {
        id:"26",
        question: "What is the hardest natural substance on planet Earth?",
        choices: ["Gold", "Diamond", "Platinuim","Rhodium"],
        correct: 1
    },
    {
        id:"27",
        question: "Which planet has 145 moons?",
        choices: ["Saturn", "Mars", "Mercury","Pluto"],
        correct: 0
    },
    {
        id:"28",
        question: "What color is the sunset on Mars?",
        choices: ["Red", "Pink", "Blue","Green"],
        correct: 2
    },
    {
        id:"29",
        question: "In which country was the game of chess invented?",
        choices: ["India", "China", "Russia","Greece"],
        correct: 0
    },
    {
        id:"30",
        question: "Which hair product was invented in 1950?",
        choices: ["Hair straightner", "Shampoo", "Condioner","Hair spray"],
        correct: 3
    },
    {
        id:"31",
        question: "When was the first ever SMS text message sent?",
        choices: ["1982", "1985", "1992","1995"],
        correct: 2
    },
    {
        id:"32",
        question: "What is the longest that an elephant has ever lived?",
        choices: ["17 years", "49 years", "86 years","142 years"],
        correct: 2
    },
    {
        id:"33",
        question: "How many rings are on the Olympic flag?",
        choices: ["None", "4", "5","7"],
        correct: 2
    },
    {
        id:"34",
        question: "How did Spider-Man get his powers?",
        choices: ["Bitten by a radioactive spider", "Born with them", "Military experiment","Woke up with them after a strange dream"],
        correct: 0
    },
    {
        id:"35",
        question: "Which of these animals does NOT appear in the Chinese zodiac?",
        choices: ["Bear", "Dog", "Dragon","Rabbit"],
        correct: 0
    },
    {
        id:"36",
        question: "What are the main colors on the flag of Spain?",
        choices: ["Black and yellow", "Blue and white", "Green and white","Red and yellow"],
        correct: 3
    },
    {
        id:"37",
        question: "Who is Jamie Oliver?",
        choices: ["A chef", "A band member", "An actor","A model"],
        correct: 0
    },
    {
        id:"38",
        question: "What is Times New Roman?",
        choices: ["A mathematical function", "A newspaper", "A font ","A religious movement"],
        correct: 2
    },
    {
        id:"39",
        question: "Where would you find the Spanish Steps?",
        choices: ["Madrid", "Mars", "New York","Rome"],
        correct: 3
    },
    {
        id:"40",
        question: "How long does it take light to travel from the Sun to the Earth?",
        choices: ["It's instantaneous", "About 8 minutes", "About 11 days","2 or 3 months"],
        correct: 1
    },
    {
        id:"41",
        question: "When did Mahatma Gandhi die?",
        choices: ["1948", "1961", "1975","1997"],
        correct: 0
    },
    {
        id:"42",
        question: "Which of these noble ranks is highest?",
        choices: ["Baron", "Duke", "Earl","Marquis"],
        correct: 1
    },
    {
        id:"43",
        question: "Which of these is NOT caused by a virus?",
        choices: ["Cholera", "Herpes", "Measles","Smallpox"],
        correct: 0
    },
    {
        id:"44",
        question: "How old was Juliet in 'Romeo and Juliet'?",
        choices: ["13", "21", "31","45"],
        correct: 0
    },
    {
        id:"45",
        question: "Which of these is NOT a type of architecture?",
        choices: ["Art Deco", "Brutalist", "Dadaist","Gothic"],
        correct: 2
    },
    {
        id:"46",
        question: "What is the key ingredient in a Molotov cocktail?",
        choices: ["Gasoline", "Milk", "Nitroglycerin","Vodka"],
        correct: 0
    },
    {
        id:"47",
        question: "What was the name of Dorothy's aunt in 'The Wizard of Oz'?",
        choices: ["Aunt Bee", "Aunt Em", "Aunt Gertrude","Aunt Rose"],
        correct: 1
    },
    {
        id:"48",
        question: "Which of these is NOT a sign of the Zodiac?",
        choices: ["Aquarius", "Leo", "Orion","Taurus"],
        correct: 2
    },
    {
        id:"49",
        question: "If you 'decimate' something, what percentage of it do you destroy ?",
        choices: ["10%", "12%", "20%","50%"],
        correct: 0
    }
  
  ];
